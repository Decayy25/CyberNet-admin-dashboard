import { Fragment } from "react";
import PageHead from "@/components/PageHead";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ClientTable from "@/components/client/ClientTable";
import ClientModal from "@/components/client/ClientModal";
import useClient from "@/hooks/useClient";
import { Plus } from "lucide-react";

const ClientPage = (): React.JSX.Element => {
  const {
    client,
    isLoading,
    isModalOpen,
    isEditMode,
    formData,
    handleInputChange,
    handleSaveClient,
    handleDeleteClient,
    openAddModal,
    openEditModal,
    closeModal,
  } = useClient();

  return (
    <Fragment>
      <PageHead title="Manajemen Client | CyberNet" />
      <Header />
      <div className="flex min-h-screen bg-[#0B0F19] text-white">
        <Sidebar />
        <main className="flex-1 p-8 overflow-y-auto pl-70 pt-20">
          <div className="max-w-7xl mx-auto space-y-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                Manajemen <span className="text-blue-400">Client</span> 
              </h1>
              <p className="text-gray-400 mt-2">
                Kelola data pelanggan dan langganan mereka
              </p>
            </div>

            <div className="flex justify-end">
              <button
                onClick={openAddModal}
                className="bg-blue-600 hover:bg-blue-500 text-white font-medium py-3 px-6 rounded-xl transition-colors flex items-center gap-2"
              >
                <Plus size={20} />
                Tambah Client Baru
              </button>
            </div>

            {/* CLIENT TABLE */}
            <ClientTable
              client={client}
              isLoading={isLoading}
              onEdit={openEditModal}
              onDelete={handleDeleteClient}
            />

            {/*  CLIENT MODAL */}
            {isModalOpen && (
              <ClientModal
                isOpen={isModalOpen}
                isEditMode={isEditMode}
                formData={formData}
                isLoading={isLoading}
                onInputChange={handleInputChange}
                onSave={handleSaveClient}
                onClose={closeModal}
              />
            )}
          </div>
        </main>
      </div>
    </Fragment>
  );
}

export default ClientPage;