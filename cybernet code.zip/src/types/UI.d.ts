export interface MembershipPlan {
  _id: string;
  paket: string;
  price: number;
  period: string;
  features: string[];
  isPopular: boolean;
}

export interface LocationArea {
  _id: string;
  area: string;
  status: "tersedia" | "tidak tersedia" | string;
}

export interface TypeContactForm {
  fullName: string;
  phoneNumber: string;
  email: string;
  address: string;
  message: string;
  packageId:
    | "PAKET 10 Mbps"
    | "PAKET 20 Mbps"
    | "PAKET 30 Mbps"
    | "PAKET 50 Mbps";
}

export interface TypeEmail {
  email: string;
  name: string;
  message: string;
}

export interface TypeLoginAdmin {
  identifier: string;
  password: string;
}

export interface typeLocation {
  _id?: string;
  area: string;
  status: "tersedia" | "tidak_tersedia";
}

export interface typeMembership {
  paket: string;
  price: number;
  period: "bulan" | "tahun";
  features: [];
  isPopular?: boolean;
}

export interface AlertProps {
  area: string;
  status: string;
  confidence: string;
  isVerified: boolean;
  matchedArea?: string;
}

export interface KPICardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: number;
  color: string;
}

export interface DashboardMetrics {
  totalLocations: number;
  activeLocations: number;
  totalMembership: number;
  averagePrice: number;
  totalClient: number;
  coverageRate: number;
}

export interface UseDashboardReturn {
  locations: typeLocation[];
  membership: MembershipPlan[];
  client: Client[];
  isLoading: boolean;
  metrics: DashboardMetrics;
  handleDataChange: () => void;
}